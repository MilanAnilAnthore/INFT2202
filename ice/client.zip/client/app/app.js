/*
    Name: Milan Anil Anthore
    filename: app.js
    Course: INFT 2202
    Date: January 10, 2025
    Description: This is my general application script.  Functions that are required on every page should live here.
*/